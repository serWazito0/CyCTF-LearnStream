"""
This is just a simulation for a gateway 
which performs schema validation for each request sent to the LeamStream API. 

This means that the API gateway checks the structure and format of the request body to ensure it complies with the defined schema before forwarding it to the LeamStream API.
"""
from flask import Flask, request, jsonify,Response
import requests
import ujson
import os
import jsonschema
from jsonschema import validate

app = Flask(__name__)

user_signup_schema = {
    "type": "object",
    "properties": {
        "user_type": {
            "type": "string",
            "enum": ["employee"]
        },
        "username": {"type": "string"},
        "first_name": {"type": "string"},
        "last_name": {"type": "string"},
        "email": {"type": "string"},
        "password": {"type": "string"}
    },
    "required": ["user_type", "username", "password", "first_name", "last_name", "email"]
}

INTERNAL_APP_BASE_URL = "http://backend:8080"

def prepare_response(res_object, status_code,origin):
    response = jsonify(res_object)
    if origin == "Backend API":
        response.headers.set('Server', origin)
    return response, status_code


@app.route('/LearnStream/signup', methods=['POST'])
def forward_signup_request():
    internal_url = f"{INTERNAL_APP_BASE_URL}/user/register"
    if not request.is_json:
        return prepare_response({"error": "Content type is not JSON"}, 400, "API Gateway")
    try:
        data = request.get_json()
    except:
        return prepare_response({"error": "No JSON data provided in the request"}, 400, "API Gateway")
    try:
        validate(instance=data, schema=user_signup_schema)
    except jsonschema.exceptions.ValidationError as e:
        if data["user_type"] != "employee": 
            return prepare_response({"error": "Only 'employee' can register."}, 400, "API Gateway")
        else: 
            return prepare_response({"error": "JSON schema validation failed"}, 400, "API Gateway")
    response = requests.post(internal_url, json=data)
    return prepare_response(response.json(), response.status_code, "Backend API")



@app.route('/LearnStream/login', methods=['POST'])
def forward_login_request():
    internal_url = f"{INTERNAL_APP_BASE_URL}/user/login"
    if not request.is_json:
        return prepare_response({"error": "Content type is not JSON"}, 400, "API Gateway")
    try:
        data = request.get_json()
    except:
        return prepare_response({"error": "No JSON data provided in the request"}, 400, "API Gateway")
    response = requests.post(internal_url, json=data)
    return prepare_response(response.json(), response.status_code, "Backend API")



@app.route('/LearnStream/videos/<path:filename>', methods=['GET'])
def forward_video_request(filename):
    internal_url = f"{INTERNAL_APP_BASE_URL}/videos/{filename}"
    headers = {'Authorization': request.headers.get('Authorization')}
    response = requests.get(internal_url, headers=headers)

    if response.status_code == 200:
        # Check the Content-Type of the response
        content_type = response.headers.get('Content-Type')
        if content_type == 'video/mp4':
            content = Response(response.content, content_type='video/mp4')
            content.headers.set('Server', "Backend API")
            return content

    else:
        return prepare_response({"error": "Video not found"}, response.status_code, "Backend API")


@app.route('/LearnStream/profile', methods=['GET'])
def forward_profile_request():
    internal_url = f"{INTERNAL_APP_BASE_URL}/user/me"
    headers = {'Authorization': request.headers.get('Authorization')}
    response = requests.get(internal_url,headers=headers)
    return prepare_response(response.json(), response.status_code, "Backend API")


@app.route('/LearnStream/courses', methods=['POST'])
def forward_courses_request():
    internal_url = f"{INTERNAL_APP_BASE_URL}/courses"
    headers = {'Authorization': request.headers.get('Authorization')}
    if not request.is_json:
        return prepare_response({"error": "Content type is not JSON"}, 400, "API Gateway")
    try:
        data = request.get_json()
    except:
        return prepare_response({"error": "No JSON data provided in the request"}, 400, "API Gateway")
    response = requests.post(internal_url, json=data,headers=headers)
    return prepare_response(response.json(), response.status_code, "Backend API")


# Route to forward course videos requests
@app.route('/LearnStream/courses/<string:course_id>/videos', methods=['POST'])
def forward_course_videos_request(course_id):
    internal_url = f"{INTERNAL_APP_BASE_URL}/courses/{course_id}/videos"
    headers = {'Authorization': request.headers.get('Authorization')}
    if not request.is_json:
        return prepare_response({"error": "Content type is not JSON"}, 400, "API Gateway")
    try:
        data = request.get_json()
    except:
        return prepare_response({"error": "No JSON data provided in the request"}, 400, "API Gateway")
    response = requests.post(internal_url, json=data,headers=headers)
    return prepare_response(response.json(), response.status_code, "Backend API")


@app.route('/LearnStream/courses/<string:course_id>/videos', methods=['GET'])
def forward_course_videos_get_request(course_id):
    internal_url = f"{INTERNAL_APP_BASE_URL}/courses/{course_id}/videos"
    headers = {'Authorization': request.headers.get('Authorization')}
    response = requests.get(internal_url,headers=headers)
    return prepare_response(response.json(), response.status_code, "Backend API")


if __name__ == '__main__':
    from waitress import serve
    serve(app, host="0.0.0.0", port=80, ident="API Gateway")
