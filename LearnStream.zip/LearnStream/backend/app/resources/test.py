# import json 

# emoji = "instructor"

# print(emoji.encode("utf-16")) # also tried "ascii", "utf-16", and "utf-16-le"
# json.loads(emoji)

import jsonschema
from jsonschema import validate
import ujson
import json

user_signup_schema = {
    "type": "object",
    "properties": {
        "user_type": {
            "type": "string",
            "enum": ["employee"]
        },
        "username": {"type": "string"},
        "first_name": {"type": "string"},
        "last_name": {"type": "string"},
        "email": {"type": "string"},
        "password": {"type": "string"}
    },
    "required": ["user_type", "username", "password", "first_name", "last_name", "email"]
}

raw = r'{"username": "qwe4", "first_name": "qq", "last_name": "ee", "email": "q4@e.com", "password": "qwe","user_type":"employee","\u0075\u0073\u0065\u0072\u005F\u0074\u0079\u0070\u0065\ud800":"instructor"}'
data = json.loads(raw)
print("JSON load output =>>>", data)

try:
    validate(instance=data, schema=user_signup_schema)
    print("Worked")
except jsonschema.exceptions.ValidationError as e:
    print("loggin as => ", data["user_type"])
    if data["user_type"] != "employee": 
        print("Only 'employee' can register.")
    else: 
        print("JSON schema validation failed")

datax = ujson.loads(raw)
print(datax['user_type'])