from flask import Flask, send_file, request
import os

app = Flask(__name__)

@app.route('/video')
def stream():
    video_path = 'path/to/your/video.mp4'
    range_header = request.headers.get('Range', None)
    
    if not range_header:
        return send_file(video_path)

    start, end = map(int, range_header.replace('bytes=', '').split('-'))
    content_length = os.path.getsize(video_path)

    if end == 0:
        end = content_length - 1

    length = end - start + 1

    headers = {
        'Content-Range': f'bytes {start}-{end}/{content_length}',
        'Content-Length': length,
        'Content-Type': 'video/mp4',
        'Accept-Ranges': 'bytes'
    }

    with open(video_path, 'rb') as f:
        f.seek(start)
        data = f.read(length)

    return data, 206, headers

if __name__ == '__main__':
    app.run(debug=True)
