import os
import sys
import requests
import uuid
from flask import request, current_app
from flask_restful import Resource
from app.models import Course, Video, User
from app import db
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt


def check_magic_bytes(chunk):
    if chunk[:4] == b"\x00\x00\x00\x18" or chunk[:8] == b"ftypmp42":
        return True
    else:
        return False


def download_video(url, video_filename, save_path):
    try:
        response = requests.head(url)
        video_size = int(response.headers["Content-Length"])
        content = response.headers["Content-Type"]
        max_video_size = 10 * 1024 * 1024  # Maximum video size (10 MB)
        max_chunk_size = 1 * 1024 * 1024  # Maximum chunk size (1 MB)

        if video_size > max_video_size:
            return (False, "Maximum video size allowed is 10 MB")
        if content != "video/mp4":
            return (False, "The file is not a video file")    
        if check_magic_bytes(requests.get(url, headers={"Range": "bytes=0-4"}).content):
            chunk_size = min(video_size, max_chunk_size)  # Initial chunk size
            num_chunks = (video_size + chunk_size - 1) // chunk_size  # Calculate the number of chunks

            with open(save_path, "ab") as f:
                for i in range(num_chunks):
                    start_byte = i * chunk_size
                    end_byte = min((i + 1) * chunk_size - 1, video_size - 1)

                    headers = {"Range": f"bytes={start_byte}-{end_byte}"}
                    response = requests.get(url, headers=headers)

                    if len(response.content) == (end_byte - start_byte + 1):  # Check if the server supports partial content
                        f.write(response.content)
                    else:
                        if os.path.exists(save_path):
                            os.remove(save_path)
                        return (False, f"An error occurred while downloading the bytes={i}-{i + chunk_size}")

            return True

        else:
            return (False, "The file is not a video file")
    except Exception as e:
        return (False, f"An error occurred")


class VideoResource(Resource):
    @jwt_required()
    def post(self, course_id):
        # Ensure that only instructors can create videos for courses
        claims = get_jwt()
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)

        # Check if the user is of type 'instructor'
        if claims.get('user_type') != 'instructor':
            return {'message': 'Only instructors can add videos for courses'}, 403

        data = request.get_json()
        video_name = data.get('name')
        video_url = data.get('video_url')

        try:
            # Convert the course_id parameter to a UUID
            course_id = uuid.UUID(course_id)
        except ValueError:
            return {'message': 'Invalid course ID format'}, 400

        # Check if the course with the specified course_id exists
        course = Course.query.filter_by(id=str(course_id)).first()

        if not course:
            return {'message': 'Course not found'}, 404

        # Generate a random GUID for the video filename
        video_filename = str(uuid.uuid4()) + '.mp4'
        save_path = os.path.join(current_app.root_path, current_app.config['UPLOAD_FOLDER'], video_filename)
        
        result = download_video(video_url, video_filename, save_path)
        if result is True:
            new_video = Video(name=video_name, path=save_path, course_id=course.id, uploader_id=current_user_id)
            db.session.add(new_video)
            db.session.commit()
            return {'message': 'Video added to the course successfully', 'video_path': f"/videos/{video_filename}", 'video_id': new_video.id}, 201

        elif isinstance(result, tuple) and result[0] is False:
            error_message = result[1]
            return {'message': result[1]}, 200

    @jwt_required()
    def get(self, course_id):
        claims = get_jwt()
        user_type = claims.get('user_type')

        # Check if the user is an employee or instructor
        if user_type not in ['employee','instructor']:
            return {'message': 'Only employees can access this resource'}, 403

        # Retrieve the course by its ID
        course = Course.query.filter_by(id=course_id).first()

        if not course:
            return {'message': 'Course not found'}, 404

        # Extract attached videos
        attached_videos = []
        for video in course.videos:
            attached_videos.append({
                'video_id': video.id,
                'video_name': video.name,
                'video_path': video.path,
            })

        return {
            'course_id': course.id,
            'videos': attached_videos,
        }

